class ConfigurationError(Exception):
    pass